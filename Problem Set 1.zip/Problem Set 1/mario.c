#include<stdio.h>
#include <cs50.h>

int main(void) 
{
    int height, c, k, space;
     do {
     printf("Height:");
     height = GetInt();
      }while (height<0 || height>23);
     
        space = height;
 
    for ( k = 2 ; k <= (height+1) ; k++ )
    {
        for ( c = 1 ; c < space ; c++ )
            printf(" ");
 
        space--; 
 
        for( c = 1 ; c <= k ; c++ )
            printf("#");
 
        printf("\n");
    }
 
}