<?php
   
    require("../includes/config.php"); 
    
    // if user reached page via GET
    if ($_SERVER["REQUEST_METHOD"] == "GET")
    {
        render("quote_form.php", ["title" => TITLE_QUOTE]);
    }
    
    // else if user reached page via POST 
    else if ($_SERVER["REQUEST_METHOD"] == "POST")
    {
        // validate submission
        if (empty($_POST["symbol"]))
        {
            apologize("Please enter a valid stock symbol to receive a quote.");
        }
        
        // lookup the stock price
        $stock = lookup($_POST["symbol"]);
        
        if ($stock != false)
        {
            render("quote.php", ["title" => TITLE_QUOTE, "stock" => $stock]);
        }
        else
        {
            apologize("Unable to lookup the quote for " . $_POST["symbol"] . ".");
        }
    }
?>