<?php

    // configuration
    require("../includes/config.php");

    // if user reached page via GET (as by clicking a link or via redirect)
    if ($_SERVER["REQUEST_METHOD"] == "GET")
    {
        // else render form
        render("register_form.php", ["title" => "Register"]);
    }

    // else if user reached page via POST (as by submitting a form via POST)
    else if ($_SERVER["REQUEST_METHOD"] == "POST")
    {
        // TODO
        
        if (empty($_POST["username"]))
        {
            apologize("Please enter a username");   
        }
        else if (empty($_POST["password"]))
        {
            apologize("Please enter a password");
        }
        else if (empty($_POST["confirmation"]))
        {
            apologize("Please re-enter your password");
        }
        else if ($_POST["password"] != $_POST["confirmation"])
        {
            apologize("Your password and confirmation do not match.");
        }
        
        // if user already exists
        $rows =CS50::query("SELECT * FROM users WHERE username = ?", $_POST["username"]);
        
        if (count($rows) == 1)
        {
            apologize(" user already exists");
        }
        else
        {
        
           // insert new user into database
            $newUser =  CS50::query("INSERT INTO users(username, hash, cash) VALUES (?, ?, ?)", $_POST["username"], crypt($_POST["password"]), 10000.00);

            if ($newUser !== false)
             {
                 $rows = CS50::query("SELECT LAST_INSERT_ID() AS id");
            
                 if (count($rows) == 1)
                  {
                    $id = $rows[0]["id"];
                    
                    $_SESSION["id"] = $id;
                    redirect("/");
                  }
                  else
                  {
                       apologize("Can not log in with this account");
                  }
             }

             else
             {
                    apologize("Account creation failed");
             } 
        }
     
    }
    
    else
    {
        // Else render form
        render("register_form.php", ["title" => "Register"]);
    }

?>


