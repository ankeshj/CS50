<div>
    <table class="table table-striped cs50">
        <thead>
            <tr>
                <td style="text-align: left;"><b>Name</b></td>
                 <td style="text-align: left;"><b>Price</b></td>
                <td style="text-align: left;"><b>Shares</b></td>
                <td style="text-align: left;"><b>Symbol</b></td>
                <td style="text-align: left;"><b>Total</b></td>
            </tr>
        </thead>
        
        <tbody>
            <?php if (!empty($positions)): ?>
                <?php foreach ($positions as $position): ?>
                    <tr>
                        <td style="text-align: left;"><?= $position["name"] ?></td>
                        <td style="text-align: left;"><?= "$" . number_format($position["price"], 2) ?></td>
                        <td style="text-align: left;"><?= number_format($position["shares"]) ?></td>
                        <td style="text-align: left;"><?= $position["symbol"] ?></td>
                        <td style="text-align: left;"><?= "$" . number_format($position["total"], 2) ?></td>
                    </tr>
                <?php endforeach ?>
           
            <?php else: ?>
                <tr>
                    <td colspan="5" style="text-align: left;">(No stocks in portfolio)</td>
                </tr>
            <?php endif ?>

        </tbody>
    </table>
</div>