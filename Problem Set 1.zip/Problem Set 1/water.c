#include<stdio.h>
#include <cs50.h>
int main() 
{
 int m = 0,bottel = 0;
  do {
   printf("Enter Minutes:");
 m=GetInt();
  }while(m<0);
  bottel = m*12;
  printf("No of bottels used: %d \n",bottel);
}