<?php
    // configuration
    require("../includes/config.php"); 	
	
    $id = $_SESSION["id"];
    
    // Retrieve all the shares this users owns
	$rows = CS50::query("SELECT * FROM portfolios WHERE user_id = $id");
				
	// positions array which stores all the information about the shares
	$positions = [];
	
	foreach ($rows as $row)
	{
	  $stock = lookup($row["symbol"]);
	  
	  if ($stock !== false)
	  {
	
	    // add shares to the row
        $stock["shares"] = $row["shares"];
        
        // add total price to the row
        $stock["total"] = $row["shares"] * $stock["price"];
        
        // save the row in the new array
        $positions[] = $stock;
        
	  }    
	}
	  
	$users = CS50::query("SELECT * FROM users WHERE id = $id");
	
    // render portfolio
    render("portfolio.php", ["title" => "Portfolio", "positions" => $positions, "users" => $users]);

?>




