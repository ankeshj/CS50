/**
 * dictionary.c
 *
 * Computer Science 50
 * Problem Set 5
 *
 * Implements a dictionary's functionality.
 */

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "dictionary.h"

int wordCount = 0; // words loaded

typedef struct list
{
	char* word;
	struct list* next;
} list;

// create a hash table of lists
list* hashTable[HASHTABLE_SIZE];

/**
 * Returns the hash value of the word
 */
int hash(const char* word)
{
    int wordLen = strlen(word);
    int hashSum = 0;
    
    // calculates the sum of the numeric values of the characters in a specified word
    for(int i = 0; i < wordLen; i++)
    {
    	hashSum += word[i];
    }
    return (hashSum % HASHTABLE_SIZE);
}

/**
 * Returns true if word is in dictionary else false.
 */
bool check(const char* word)
{

    char checkWord[LENGTH+1];
    char lowerWord;
    
    // convert all uppercase letters to lowercase
    for(int i = 0; i < strlen(word); i++)
    {
    	lowerWord = tolower(word[i]);
    	checkWord[i] = (char)lowerWord;
    }

    checkWord[strlen(word)] = '\0';
    
    int hashIndex = hash(checkWord);
  
    list* temp = hashTable[hashIndex];
  
    if(temp == NULL)
    {
    	return false;
    }
    
    while(temp != NULL)
    {
    	if(!strcmp(checkWord,temp->word))
    	{
    		return true;
    	}
    	temp = temp->next;
    }
    return false;
}

/**
 * Loads dictionary into memory.  Returns true if successful else false.
 */
bool load(const char* dictionary)
{
   FILE* fp = NULL;
   int hashIndex = 0 ;
   char dictWord[LENGTH+1];
   
   // open the dictionary
   fp = fopen(dictionary, "r");
   
   if(fp == NULL)
   {
   	return false;
   }
   
   // read the dictionary and create the hash table
   while(fscanf(fp,"%s\n", dictWord) != EOF)
   {
	   	// create new list size of list
	   	list* newList = malloc(sizeof(list));
	   	// allocate the maximum size of the word for memory
	   	newList->word = malloc(strlen(dictWord)+1);
	   	// copy the new word into the linked list 
	   	strcpy(newList->word,dictWord);
	  
	   	hashIndex = hash(dictWord);
	   	wordCount++;
	   	
	   	if(hashTable[hashIndex] == NULL)
	   	{
	   		hashTable[hashIndex] = newList;
	   		newList->next = NULL;
	   	}else
	   	{
	   		newList->next = hashTable[hashIndex];
	   		hashTable[hashIndex] = newList;
	   	}   	
   	
   }
   
    fclose(fp);
	return true;
}

/**
 * Returns number of words in dictionary if loaded else 0 if not yet loaded.
 */
unsigned int size(void)
{
    return wordCount;
}

/**
 * Unloads dictionary from memory.  Returns true if successful else false.
 */
bool unload(void)
{
    list* temp = NULL;
	list* temp2 = NULL;
	
	for(int i = 0; i < HASHTABLE_SIZE;i++)
	{
		temp = hashTable[i];
		
		// if there is only one linked list present free this linked list
		
		if(temp && !temp->next)
		{
			free(temp->word);
			free(temp);
		}
			// goes through all the linked list and frees them one at a time
		else
		{
		
			while(temp)
			{
				temp2 = temp->next;
				free(temp->word);
				free(temp);
				temp = temp2;
			}
		}
		hashTable[i] = NULL;
	}
	return true;
}
